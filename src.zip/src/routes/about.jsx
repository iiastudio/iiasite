import React from "react"

class About extends React.Component{
    render(){
        return <p>這邊是關於我們</p>
    }
}
export {About}