import logo from './logo.svg';
import './App.css';
import { Link } from "react-router-dom";
import Canvas from './component/Canvas';
import { Navbar, Nav, NavDropdown, Container } from 'react-bootstrap';

function App() {
  return (
    <div className="App">
      <Navbar scrolling bg="dark" expand="lg" className="fixed-top transparent">
      <Container>
        <Navbar.Brand href="#home">IIA</Navbar.Brand>
        <Nav>
          <Navbar.Toggle aria-controls="responsive-navbar-nav" />
          <Navbar.Collapse id="basic-navbar-nav">
            <Nav className="me-auto">
              <Nav.Link href="/about">About</Nav.Link>
              <NavDropdown title="Projects" id="projects-nav-dropdown">
                <NavDropdown.Item eventKey="disabled" >2022Spring</NavDropdown.Item>
                <NavDropdown.Divider />
                <NavDropdown.Item href="/projects/bim">BIM</NavDropdown.Item>
                <NavDropdown.Item href="/projects/undergraduated">Undergraduated</NavDropdown.Item>
              </NavDropdown>
            </Nav>
          </Navbar.Collapse>
        </Nav>
      </Container>
      </Navbar>
      <Canvas />
    </div>
  );
}

export default App;
